// Load existing key on open (masked)
chrome.storage.local.get('apiKey', ({ apiKey }) => {
  if (apiKey) document.getElementById('key').placeholder = 'sk-ant-••••••••' + apiKey.slice(-4);
});

function save() {
  const val = document.getElementById('key').value.trim();
  if (!val.startsWith('sk-ant-')) {
    document.getElementById('status').textContent = '⚠ Key should start with sk-ant-';
    document.getElementById('status').style.color = '#f87171';
    return;
  }
  chrome.storage.local.set({ apiKey: val }, () => {
    document.getElementById('status').textContent = '✓ Saved';
    document.getElementById('status').style.color = '#4ade80';
    document.getElementById('key').value = '';
    document.getElementById('key').placeholder = 'sk-ant-••••••••' + val.slice(-4);
  });
}
